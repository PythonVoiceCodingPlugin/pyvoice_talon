""" Tets base JSON-RPC structures."""
